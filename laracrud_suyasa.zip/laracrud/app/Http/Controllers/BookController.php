<?php

namespace App\Http\Controllers;
use App\Models\Donation;
use Illuminate\Http\Request;

class BookController extends Controller
{
    //Show
    public function index()
    {
        $donations = Donation::orderBy('id','desc')->paginate(6);
        return view('donations.index', compact('donations'));
    }

    //Create
    public function create()
    {
        return view('donations.create');
    }

    //Store
    public function store(Request $request)
    {
        $request->validate([
            'book' => 'required',
            'contributor' => 'required',
            'email' => 'required',
            'contact' => 'required',
        ]);
        
        Donation::create($request->post());

        return redirect()->route('donations.index')->with('success');
    }

    //Display
    public function show(Donation $donation)
    {
        return view('donations.show',compact('donation'));
    }

    //Edit
    public function edit(Donation $donation)
    {
        return view('donations.edit',compact('donation'));
    }

    //Update
    public function update(Request $request, Donation $donation)
    {
        $request->validate([
            'book' => 'required',
            'contributor' => 'required',
            'email' => 'required',
            'contact' => 'required',
        ]);
        
        $donation->fill($request->post())->save();

        return redirect()->route('donations.index')->with('success');
    }

    //Delete
    public function destroy(Donation $donation)
    {
        $donation->delete();
        return redirect()->route('donations.index')->with('success');
    }
}
