<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    ///Create Tables
    public function up()
    {
        Schema::create('donations', function (Blueprint $table) {
            $table->id();
            $table->string('book');
            $table->string('contributor');
            $table->string('email');
            $table->string('contact');
            $table->timestamps();
        });
    }

    //Reverse
    public function down()
    {
        Schema::dropIfExists('donations');
    }
};
