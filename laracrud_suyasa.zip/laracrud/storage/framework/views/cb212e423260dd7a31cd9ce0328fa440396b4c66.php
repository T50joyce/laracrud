<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laravel 9 CRUD Book Donations</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <div class="container mt-2">
    <br>    
    <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2> Book Donations <a class="btn btn-primary" href="<?php echo e(route('donations.create')); ?>" style="float:right;" > Add New Donation </a> </h2>
                </div>
            </div>
        </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>B.No</th>
                    <th>Book Title</th>
                    <th>Contributor</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th width="170px">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($donation->id); ?></td>
                        <td><?php echo e($donation->book); ?></td>
                        <td><?php echo e($donation->contributor); ?></td>
                        <td><?php echo e($donation->email); ?></td>
                        <td><?php echo e($donation->contact); ?></td>
                        <td>
                            <form action="<?php echo e(route('donations.destroy',$donation->id)); ?>" method="Post">
                                <a class="btn btn-primary" href="<?php echo e(route('donations.edit',$donation->id)); ?>">Edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure to delete this data? You cant restore it once its deleted.')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo $donations->links(); ?>

    </div>
</body>
</html><?php /**PATH C:\Users\Joyce Ann Suyasa\Desktop\laravel\laracrud\resources\views/donations/index.blade.php ENDPATH**/ ?>