<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Donation Details</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-2">
        <br>
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Edit Donation Record <a class="btn btn-primary" href="{{ route('donations.index') }}" enctype="multipart/form-data" style="float:right;">Back</a></h2>
                </div>
            </div>
        </div>
        @if(session('status'))
        <div class="alert alert-success mb-1 mt-1">
            {{ session('status') }}
        </div>
        @endif
        <form action="{{ route('donations.update',$donation->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group" style="float:left; width:500px;">
                        <strong>Book Title:</strong>
                        <input type="text" name="book" value="{{ $donation->book }}" class="form-control"
                            placeholder="Book Title">
                        @error('book')
                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group" style="float:right; width:500px;">
                        <strong>Contributor:</strong>
                        <input type="text" name="contributor" value="{{ $donation->contributor }}" class="form-control"
                            placeholder="Contributor's Name">
                        @error('contributor')
                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group" style="float:left; width:500px;">
                        <strong>Contributor's Email:</strong>
                        <input type="email" name="email" class="form-control" placeholder="Contributor's Email"
                            value="{{ $donation->email }}">
                        @error('email')
                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group" style="float:right; width:500px;">
                        <strong>Contact Number:</strong>
                        <input type="number" name="contact" value="{{ $donation->contact }}" class="form-control"
                            placeholder="Contributor's Contact Number">
                        @error('contact')
                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <button type="submit" class="btn btn-primary ml-3">Submit</button>
            </div>
        </form>
    </div>
</body>

</html>