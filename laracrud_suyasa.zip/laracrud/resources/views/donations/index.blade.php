<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laravel 9 CRUD Book Donations</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    @vite('resources/css/app.css')
</head>
<body>
    <div class="container mt-2">
        <br>    
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2> Book Donations 
                        <a class="btn btn-primary" href="{{ route('donations.create') }}" style="float:right;">
                        Add New Donation</a> </h2>
                </div>
            </div>
        </div>
        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>B.No</th>
                    <th>Book Title</th>
                    <th>Contributor</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th width="170px">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($donations as $donation)
                    <tr>
                        <td>{{ $donation->id }}</td>
                        <td>{{ $donation->book }}</td>
                        <td>{{ $donation->contributor }}</td>
                        <td>{{ $donation->email }}</td>
                        <td>{{ $donation->contact }}</td>
                        <td>
                            <form action="{{ route('donations.destroy', $donation->id) }}" method="Post">
                                <a class="btn btn-primary" href="{{ route('donations.edit', $donation->id) }}">Edit</a>
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger"
                                onclick="return confirm('Are you sure to delete this data?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
            </tbody>
        </table>
        {!! $donations->links() !!}
    </div>
</body>
</html>