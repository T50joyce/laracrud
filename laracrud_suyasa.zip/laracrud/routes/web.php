<?php

use App\Http\Controllers\BookController;
 
Route::resource('donations', BookController::class);

